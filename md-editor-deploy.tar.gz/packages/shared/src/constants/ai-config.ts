export const DEFAULT_SERVICE_ENDPOINT = `https://proxy-ai.doocs.org/v1`
export const DEFAULT_SERVICE_TEMPERATURE = 1
export const DEFAULT_SERVICE_MAX_TOKEN = 1024
export const DEFAULT_SERVICE_TYPE = `default`
export const DEFAULT_SERVICE_KEY = ``
