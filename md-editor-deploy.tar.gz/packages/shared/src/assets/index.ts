/**
 * 共享资源导出
 */

// 默认自定义主题模板
export { default as DEFAULT_CUSTOM_THEME } from './default-custom-theme.txt?raw'
