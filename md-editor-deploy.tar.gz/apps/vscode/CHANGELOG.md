# doocs-md changelog

## [Unreleased] - 2025-06-04

### ✨ Features

- 侧边栏Markdown预览视图功能
- 支持微信图文特有的样式渲染
- 可自定义字体和字体大小
- 支持自定义文本主题颜色和主题样式
- 显示字数统计状态栏
- 支持 Mac 风格代码块切换
