export { default as SearchTab } from './SearchTab.vue'
