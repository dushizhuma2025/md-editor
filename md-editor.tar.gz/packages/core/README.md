# @md/core

核心渲染引擎，用于将 Markdown 文本渲染为 HTML 内容。
