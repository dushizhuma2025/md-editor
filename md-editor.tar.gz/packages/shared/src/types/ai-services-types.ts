export interface ServiceOption {
  value: string
  label: string
  endpoint: string
  models: string[]
}

export interface ImageServiceOption {
  value: string
  label: string
  endpoint: string
  models: string[]
}
