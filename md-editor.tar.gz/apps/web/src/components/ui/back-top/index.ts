export { default as BackTop } from './BackTop.vue'
